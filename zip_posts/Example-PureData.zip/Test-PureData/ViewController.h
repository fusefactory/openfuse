//
//  ViewController.h
//  Test-PureData
//
//  Created by Matteo on 24/11/2017.
//  Copyright © 2017 Matteo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PDPatch.h"

@interface ViewController : UIViewController

@property PDPatch *pdPatch;

@end
