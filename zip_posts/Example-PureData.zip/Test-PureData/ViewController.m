//
//  ViewController.m
//  Test-PureData
//
//  Created by Matteo on 24/11/2017.
//  Copyright © 2017 Matteo. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.pdPatch = [[PDPatch alloc] initWithFile:@"test-iOS.pd"];
}

- (IBAction)onSwitchChange:(id)sender {
        [self.pdPatch onOff: [sender isOn]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
