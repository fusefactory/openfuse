//
//  PDPatch.h
//  TestPureData
//
//  Created by Matteo on 18/07/2017.
//  Copyright © 2017 Fuse Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PDPatch : NSObject

- (instancetype) initWithFile:(NSString *) pdFile;
- (void) onOff:(BOOL) yesNo;

@end
