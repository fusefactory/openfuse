//
//  PDPatch.m
//  TestPureData
//
//  Created by Matteo on 18/07/2017.
//  Copyright © 2017 Fuse Interactive. All rights reserved.
//

#import "PDPatch.h"
#import "PdBase.h"

@implementation PDPatch

- (instancetype) initWithFile:(NSString *)pdFile{
    self = [super init];
    if (self){
        void * patch = [PdBase openFile:pdFile path:[NSBundle mainBundle].resourcePath];
        if (! patch){
            NSLog(@"Failed to load patch %@", pdFile);
        }
    }
    
    return self;
}

- (void) onOff:(BOOL) yesNo{
    float yn = (float)yesNo;
    [PdBase sendFloat:yn toReceiver:@"onOff"];
}

@end
