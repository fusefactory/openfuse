//
//  AppDelegate.h
//  Test-PureData
//
//  Created by Matteo on 24/11/2017.
//  Copyright © 2017 Matteo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PdAudioController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) PdAudioController *pdAudioController;

@end

